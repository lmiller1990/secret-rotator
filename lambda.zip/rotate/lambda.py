import uuid
import boto3


def handler(event, context):
    print("Hello, world!")

    return {"msg": "hello"}
