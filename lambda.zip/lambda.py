import uuid
import boto3


def handler():
    print("Hello, world!")

    return {"msg": "hello"}
